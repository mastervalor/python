from flask import Flask
app = Flask(__name__)
app.secret_key = "d247ftv2e7ycdb29uc9"